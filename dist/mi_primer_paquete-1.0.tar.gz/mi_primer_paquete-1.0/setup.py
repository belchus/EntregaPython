from setuptools import setup

setup(
   name='mi_primer_paquete',
   version='1.0',
   description='Paquete de ejemplo',
   author='Camila',
   author_email='cami@coder.com',
   packages=['mi_primer_paquete'] 

)